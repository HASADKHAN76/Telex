# Vela Wallet — deployment readiness checklist

**Status: login & admin code packaged; NOT a validated production custody wallet.**

- [x] Existing emerald-and-black mobile/desktop UI retained
- [x] User sign-up, sign-in, sign-out, change password and secure HttpOnly session handling implemented in source
- [x] Admin list of users, deposit reports, suspension/restore controls, server-side role checks
- [x] Single fixed BSC receive address and matching QR
- [x] Unit tests pass and file/syntax checks pass
- [x] Supabase database tables, RLS policies and signup trigger migrated; security advisor reviewed. Some intentionally authenticated security-definer helper warnings remain to be independently audited.
- [ ] Supabase Auth Email provider configured as desired
- [ ] GitHub repository updated with **unzipped** contents
- [ ] Netlify configured/redeployed with `public` publish + functions and environment variables
- [ ] Admin account setup (left unchanged, not part of this regular-user release)
- [ ] Live Signup/Login/Logout, password change, admin denial, suspension and mobile UI verified against production
- [ ] Independent security, custody and on-chain transaction verification review before real funds

No private wallet key exists in code. Send, withdrawals, swaps and deposit crediting are disabled by design.
