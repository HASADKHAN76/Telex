import {readFileSync,existsSync} from 'node:fs';
const required=['public/index.html','public/app.js','public/styles.css','public/status.html','public/status.js','public/receive-qr.png','netlify/functions/api.mjs','supabase/migrations/20261012_secure_wallet_accounts.sql','netlify.toml'];
for(const f of required)if(!existsSync(f))throw Error('Missing build file: '+f);
const toml=readFileSync('netlify.toml','utf8');if(!/publish\s*=\s*"public"/.test(toml))throw Error('Publish dir must be public');
const ui=readFileSync('public/index.html','utf8');if(!ui.includes('0x0428211045A993b24cAe9fB8dDE2f9BFaee71c5a'))throw Error('Missing fixed destination');
if(/admin-setup-form/.test(ui))throw Error('Insecure public admin setup form detected');
console.log('Vela static assets, secure Supabase gateway, schema and Netlify config present.');
