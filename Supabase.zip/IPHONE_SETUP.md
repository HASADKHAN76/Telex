# iPhone setup — Vela Wallet Supabase Edition

1. Supabase SQL Editor (new project): https://supabase.com/dashboard/project/bqydulyvwvywgpxrdeik/sql/new
2. Paste and run the SQL from `supabase/migrations/20261012_secure_wallet_accounts.sql` (file included in ZIP).
3. Authentication → Sign In / Providers → Email: enable email/password; turn off Confirm Email **only if you accept email-impersonation risk**.
4. Upload project files (not single ZIP) to GitHub; Netlify import from GitHub; `npm run build`, publish `public`, functions `netlify/functions`.
5. Netlify environment variables: `APP_ORIGIN=https://walletvera.netlify.app` and optionally the public `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` shown in README.
6. Open `https://walletvera.netlify.app/status.html`, then `/signup`; register your personal account with a NEW password not pasted in chat.
7. Run the admin promotion SQL from README in Supabase SQL Editor; log out and log back in. Your account then opens Admin Dashboard.

Do not accept real USDT deposits or promise real user balances; blockchain accounting is deliberately disabled until security review and verification are complete.
