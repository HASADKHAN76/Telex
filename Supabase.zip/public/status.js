'use strict';
fetch('/api?op=health',{cache:'no-store'}).then(async r=>{
 if(!r.ok)throw Error('HTTP '+r.status);
 const j=await r.json();if(!j.ok)throw Error('Service not responding');
 document.getElementById('state').textContent='API reachable';
 document.getElementById('detail').textContent='Netlify API is responding. Signup, Supabase database schema and login still require end-to-end testing.';
}).catch(e=>{document.getElementById('state').textContent='API unavailable';document.getElementById('detail').textContent='Check Netlify deployment and Functions logs. '+e.message});
