-- Vela Wallet: Supabase Auth profiles and restricted financial records.
-- No wallet keys, deposit auto-credit, or blockchain send functionality.
create table if not exists public.wallet_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text not null default '',
  role text not null default 'user' check (role in ('user','admin')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.wallet_balances (
  user_id uuid not null references auth.users(id) on delete cascade,
  asset text not null check (asset in ('USDT','BNB')),
  available numeric(38,18) not null default 0 check (available >= 0),
  reserved numeric(38,18) not null default 0 check (reserved >= 0),
  primary key (user_id,asset)
);
create table if not exists public.deposit_claims (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  asset text not null check (asset in ('USDT','BNB')),
  amount numeric(38,18) not null check (amount > 0 and amount < 1000000000000000),
  tx_hash text not null unique check (tx_hash ~ '^0x[0-9a-fA-F]{64}$'),
  status text not null default 'pending' check (status in ('pending','verified','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewer_id uuid references auth.users(id),
  note text
);
create index if not exists deposit_claims_user_created_idx on public.deposit_claims (user_id,created_at desc);
create table if not exists public.withdrawal_requests (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  asset text not null check (asset in ('USDT','BNB')),
  amount numeric(38,18) not null check (amount > 0),
  destination text not null,
  tx_hash text unique,
  status text not null default 'pending' check (status in ('pending','settled','rejected')),
  created_at timestamptz not null default now()
);
create table if not exists public.wallet_audit (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  subject_id uuid,
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.wallet_is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.wallet_profiles p where p.id = (select auth.uid()) and p.role='admin' and p.active) $$;
create or replace function public.wallet_is_active()
returns boolean language sql stable security definer set search_path = ''
as $$ select exists(select 1 from public.wallet_profiles p where p.id = (select auth.uid()) and p.active) $$;

create or replace function public.wallet_new_auth_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.wallet_profiles(id,email,full_name,role,active)
  values(new.id, coalesce(new.email,''), left(coalesce(new.raw_user_meta_data->>'full_name',''),100),'user',true)
  on conflict (id) do nothing;
  insert into public.wallet_balances(user_id,asset)
  values(new.id,'USDT'),(new.id,'BNB') on conflict do nothing;
  return new;
end $$;
drop trigger if exists wallet_auth_created on auth.users;
create trigger wallet_auth_created after insert on auth.users
for each row execute function public.wallet_new_auth_user();

-- Block direct client writes to profiles, balances and financial approvals.
alter table public.wallet_profiles enable row level security;
alter table public.wallet_balances enable row level security;
alter table public.deposit_claims enable row level security;
alter table public.withdrawal_requests enable row level security;
alter table public.wallet_audit enable row level security;

create policy "profile visible to self or active admin" on public.wallet_profiles
for select to authenticated using ((id = (select auth.uid()) and public.wallet_is_active()) or public.wallet_is_admin());
create policy "balance visible to self or active admin" on public.wallet_balances
for select to authenticated using ((user_id = (select auth.uid()) and public.wallet_is_active()) or public.wallet_is_admin());
create policy "claim visible to self or active admin" on public.deposit_claims
for select to authenticated using ((user_id = (select auth.uid()) and public.wallet_is_active()) or public.wallet_is_admin());
create policy "allow pending claim by active owner" on public.deposit_claims
for insert to authenticated with check (
 user_id=(select auth.uid()) and public.wallet_is_active() and status='pending'
 and reviewer_id is null and reviewed_at is null and note is null
);
create policy "withdrawal visible to self or active admin" on public.withdrawal_requests
for select to authenticated using ((user_id = (select auth.uid()) and public.wallet_is_active()) or public.wallet_is_admin());
create policy "audit visible to admins" on public.wallet_audit
for select to authenticated using (public.wallet_is_admin());

-- Admin status changes only via a definer function that rechecks role.
create or replace function public.wallet_admin_set_active(p_user uuid, p_active boolean)
returns boolean language plpgsql security definer set search_path = ''
as $$
declare changed integer;
begin
  if not public.wallet_is_admin() then raise exception 'Admin permission required' using errcode='42501'; end if;
  if p_user is null or p_active is null then raise exception 'Missing user/status'; end if;
  if p_user=(select auth.uid()) then raise exception 'Cannot change your own account'; end if;
  update public.wallet_profiles p set active=p_active where p.id=p_user and p.role='user' and p.active is distinct from p_active;
  get diagnostics changed = row_count;
  if changed <> 1 then raise exception 'Member not found or already in requested state'; end if;
  insert into public.wallet_audit(actor_id,action,subject_id)
  values((select auth.uid()), case when p_active then 'member_restored' else 'member_suspended' end,p_user);
  return true;
end $$;

-- Revocations protect SECURITY DEFINER functions from anonymous calls.
revoke all on function public.wallet_is_admin() from public,anon;
revoke all on function public.wallet_is_active() from public,anon;
revoke all on function public.wallet_admin_set_active(uuid,boolean) from public,anon;
grant execute on function public.wallet_is_admin() to authenticated;
grant execute on function public.wallet_is_active() to authenticated;
grant execute on function public.wallet_admin_set_active(uuid,boolean) to authenticated;

-- Explicit minimal PostgREST privileges; RLS still applies.
revoke all on public.wallet_profiles,public.wallet_balances,public.deposit_claims,public.withdrawal_requests,public.wallet_audit from public,anon,authenticated;
grant select on public.wallet_profiles,public.wallet_balances,public.deposit_claims,public.withdrawal_requests,public.wallet_audit to authenticated;
grant insert (user_id,asset,amount,tx_hash) on public.deposit_claims to authenticated;
grant usage,select on sequence public.deposit_claims_id_seq to authenticated;
-- No client role receives UPDATE / DELETE of financial records or wallet_balances.
