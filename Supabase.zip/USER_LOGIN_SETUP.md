# Vela Wallet — regular-user login (Supabase)

**Admin Dashboard has not been modified in this release.** This setup is only for ordinary members.

## Already configured in Supabase

Project ID: `bqydulyvwvywgpxrdeik` (Mumbai). `wallet_profiles`, `wallet_balances`, `deposit_claims`, `withdrawal_requests`, and `wallet_audit` tables exist. All have row-level security enabled. A real signup creates an `auth.users` record, a `wallet_profiles` row with `role = user`, and two ledger rows initially equal to zero.

The website connects through the Netlify function. Passwords are authenticated by Supabase; no default accounts, browser-only fake login, or wallet creation/import.

## Remaining dashboard steps (iPhone)

1. Supabase: [Auth Email provider](https://supabase.com/dashboard/project/bqydulyvwvywgpxrdeik/auth/providers) → Email enabled. To allow instant signup without confirmation (as you requested), set **Confirm Email = OFF** and save; note impersonation risk, and strongly consider enabling verification before public financial launch. This account's auth provider settings have NOT been changed automatically.
2. Upload the **extracted files** from the ZIP (NOT the ZIP as a single file) to your GitHub repository. Preserve the `public`, `netlify`, `tests`, `scripts`, and other directories.
3. Netlify `walletvera`: link the repository and redeploy with Build command `npm run build`, Publish directory `public`, Functions directory `netlify/functions`; do not use `.next`.
4. Netlify site environment variables: `APP_ORIGIN=https://walletvera.netlify.app`, `SUPABASE_URL=https://bqydulyvwvywgpxrdeik.supabase.co`, `SUPABASE_PUBLISHABLE_KEY=sb_publishable_ikviNQHz6fR-jy1DVX4zJQ_LVxETBIr`. All are public config; **never** place secret/service role credentials in frontend or repository.
5. After Netlify completes deployment: open `https://walletvera.netlify.app/status.html`, then `/signup`. Create one test member using an email address YOU control and a new unique 12+ character password. Test logout, login, account page and Receive QR. In Supabase Auth → Users, check the new account; in `public.wallet_profiles`, it should have `role = user`.

## Important safety / scope

- Every user sees the same operator-supplied USDT BEP-20/BNB receiving address. No customer wallets are created.
- A payment to the shared BSC address cannot be reliably attributed to an account from transaction hash alone. This version **does not auto-credit balances or send transfers**.
- Project code is tested locally; we cannot certify live Netlify/Supabase end-to-end login before deployment and actual signup test.
- Do not use the app to collect real customer deposits until custody, accounting, security and compliance review.
