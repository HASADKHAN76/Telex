# Vela Wallet — Supabase Auth + Netlify edition

This is the **same premium emerald/black Vela Wallet interface** with a secure server-side gateway for **Supabase email/password authentication**, a protected administrator screen and a fixed BSC receive address. **No wallet creation or import. No built-in wallet keys.** All registered visitors see the same receiving address:

`0x0428211045A993b24cAe9fB8dDE2f9BFaee71c5a` · BNB Smart Chain mainnet (chain ID 56).

## What works after deployment and migration

- Register / log in with email and password through **Supabase Auth**, server-side session stored in **Secure, HttpOnly, SameSite=Strict** cookies. Public project key only (no service role or wallet key).
- Logout, change password (checks current password), redirect ordinary members to wallet dashboard and admins to admin dashboard based on Supabase DB role.
- Protected Supabase profiles, read-only user balances, admin list of users and claimed deposits, suspend/restore ordinary members, audit events.
- Real pending deposit-claim submissions (hash/amount metadata) and personal activity; **deposit claims are not validated, attributed or credited**.
- Receive screen, local scannable QR, Copy and BscScan links; no fake transfer history, generated accounts or fake balances.
- `GET /api?op=health` and `/status.html` allow a **gateway-only** availability check; not an end-to-end production proof.

**Deliberately disabled:** on-chain transfers, swaps, manual balance crediting, automated deposit approval, withdrawal execution, custody of wallet signing keys. These require external security review, payment attribution and blockchain settlement engineering. **Do not solicit or accept public deposits until the entire financial flow has been independently tested and audited.**

## Current status (12 October 2026)

✅ Connected Supabase project `bqydulyvwvywgpxrdeik`: five wallet tables were created, row-level security enabled, automatic normal-user profile/balance creation installed, and anonymous/regular-user balance edits denied. The signup-trigger function was locked down separately.

✅ Local JavaScript tests and static Netlify build check pass. This release leaves administrator routing and policy unchanged.

⚠️ **NOT DEPLOYED:** Netlify has not been updated with these files and live browser signup/login has not been verified. Also confirm **Authentication → Sign In / Providers → Email**, public signup enabled, and **Confirm Email** setting. No real withdrawals or automatic deposit crediting are implemented. Do not solicit public funds.

## iPhone setup, exact steps

1. Open your **Vela Wallet** project [Supabase dashboard](https://supabase.com/dashboard/project/bqydulyvwvywgpxrdeik). Project reference: `bqydulyvwvywgpxrdeik`. This is the **new** project, not the earlier `haeozknkmwpcybobipkl` project.
2. In Supabase, go to **Authentication → Sign In / Providers → Email**. Enable email/password. If you still want immediate registration without verifying email, disable **Confirm Email**. Security warning: anyone can register using an email they don't control; verification is strongly advised for a wallet/financial product. Keep strong password rules and use admin MFA when available.
3. **Already completed for your new project:** wallet tables, signup trigger and RLS are deployed. **Do not rerun the included original SQL migration**, which may fail on duplicate policies. The SQL file is provided only as a source reference. View your tables in Supabase Table Editor if desired.
4. Extract the project ZIP; upload **all contents** to a GitHub repository: `public/`, `netlify/`, `supabase/`, `scripts/`, `tests/`, `package.json`, `netlify.toml`, etc. Do **not** commit personal passwords, tokens, database connection strings or wallet keys. Do not upload the ZIP as the only file. Make the repo private initially.
5. Netlify → **Add new project → Import from GitHub** (or switch `walletvera` to the new repository/branch). Use repository root as Base Directory, `npm run build` as Build command, **`public`** as Publish Directory, and `netlify/functions` as Functions Directory (from `netlify.toml`). Do **not** use `.next`: this is no longer a Next.js app. A manual static ZIP drop won't deploy Netlify functions.
6. Netlify → **Project configuration → Environment variables** (recommended): `APP_ORIGIN=https://walletvera.netlify.app`, `SUPABASE_URL=https://bqydulyvwvywgpxrdeik.supabase.co`, `SUPABASE_PUBLISHABLE_KEY=sb_publishable_ikviNQHz6fR-jy1DVX4zJQ_LVxETBIr`. The latter two are PUBLIC values already provided as non-secret fallbacks; they are not private service keys. Set APP_ORIGIN to the **exact production origin** you use. Redeploy after changes.
7. Open `https://walletvera.netlify.app/status.html`. It should say **API reachable**. Then visit `/signup` and register a test user. If registration requires confirmation, revisit step 2. Check that the new user appears in **Supabase → Authentication → Users** and **public.wallet_profiles**. Test Sign Out and Sign In. Test that a logged-out visitor can't open `/admin`.
8. **Optional administrator setup (unchanged; ignore for normal members):** Register your personal email as an ordinary member through `/signup`, with a **new strong password not shared in chat**. Go to Supabase **SQL Editor** and run this after substituting your own email:

   ```sql
   UPDATE public.wallet_profiles
   SET role = 'admin'
   WHERE id = (SELECT id FROM auth.users WHERE email = 'YOUR_OWN_EMAIL@DOMAIN.COM')
     AND active = true;
   ```

   Review the affected row; the account must already exist and the email must match exactly. Log out and sign in again. Your admin screen appears by default and contains members, claim reports and suspend/restore. **Never** expose an endpoint or website button that changes users' role directly.
9. Run **end-to-end verification**: register test user, login, logout, password change, admin login, admin authorization denial for ordinary users, RLS checks, different browser session, account suspension, BSC QR validation, and Netlify logs. Address all security advisor findings before any real customer deployment.

## Debugging

- `/signup` 404: wrong publish directory or missing Netlify redirects; set publish dir `public`.
- Login backend unavailable / HTML instead of JSON: API function not deployed; GitHub deploy must include `netlify/functions/api.mjs`.
- 400 / error code from Supabase: inspect Netlify Functions logs; confirm Auth Email provider and project settings.
- `wallet_profiles` not found: SQL migration from step 3 not applied.
- Account registered but 'account unavailable': missing registration trigger or account suspension.
- Admin role still `user`: manually promote existing user in SQL Editor, not via browser or untrusted API.
- 403 Invalid origin: set `APP_ORIGIN` to the exact browser origin, redeploy.

## Security notes

- Supabase **publishable** API key is public, while `service_role`, `sb_secret`, DB password, private key and seed phrases must **never** be put in GitHub, frontend, messages or files intended for download.
- DB tables use RLS and only client-select/pending-claim inserts; no direct client writes to balances or admin role. Administrator status updates are a secured Postgres function.
- Single shared BSC address cannot establish which account sent a payment. The app does **not** credit balances or perform transfers. Its displayed ledger can never be assumed to equal on-chain custody holdings.
- Admins should use MFA, email verification, monitoring and independent penetration/security testing before any money-handling deployment.
