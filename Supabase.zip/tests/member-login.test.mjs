import {test,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {handler} from '../netlify/functions/api.mjs';
const original=globalThis.fetch;
afterEach(()=>{globalThis.fetch=original;});
const uid='11111111-1111-4111-8111-111111111111';
const headers={host:'walletvera.netlify.app',origin:'https://walletvera.netlify.app','sec-fetch-site':'same-origin'};
const request=(op,method='POST',data={})=>({httpMethod:method,queryStringParameters:{op},headers:{...headers},body:JSON.stringify(data)});
test('regular member can sign in using Supabase token endpoint',async()=>{
 globalThis.fetch=async (url,opts)=>{
   assert.match(String(url),/\/auth\/v1\/token\?grant_type=password$/);
   assert.equal(JSON.parse(opts.body).email,'member@example.com');
   return new Response(JSON.stringify({access_token:'supabase.mock.jwt',refresh_token:'mock.refresh',expires_in:3600,user:{id:uid}}),{status:200});
 };
 const res=await handler(request('login','POST',{email:'MEMBER@example.com',password:'strong-password-123'}));
 assert.equal(res.statusCode,200);
 assert.equal(JSON.parse(res.body).ok,true);
 assert.match(res.multiValueHeaders['Set-Cookie'].join(' '),/__Host-vela_access=/);
});
test('member session can retrieve only their own zero account balances',async()=>{
 globalThis.fetch=async(url)=>{
   const v=String(url);
   if(v.endsWith('/auth/v1/user'))return new Response(JSON.stringify({id:uid,email:'member@example.com'}),{status:200});
   if(v.includes('/wallet_profiles'))return new Response(JSON.stringify([{id:uid,email:'member@example.com',full_name:'Member',role:'user',active:true}]),{status:200});
   if(v.includes('/wallet_balances'))return new Response(JSON.stringify([{asset:'USDT',available:'0',reserved:'0'},{asset:'BNB',available:'0',reserved:'0'}]),{status:200});
   if(v.includes('/deposit_claims'))return new Response('[]',{status:200});
   throw new Error('Unmocked endpoint');
 };
 const event=request('me','GET');event.headers.cookie='__Host-vela_access=mock.access';
 const res=await handler(event);assert.equal(res.statusCode,200);
 const data=JSON.parse(res.body);
 assert.equal(data.user.role,'user');assert.equal(data.balances.USDT.available,'0');assert.deepEqual(data.activity,[]);
});
