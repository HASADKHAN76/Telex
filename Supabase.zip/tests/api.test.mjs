import {test,afterEach} from 'node:test';
import assert from 'node:assert/strict';
import {handler} from '../netlify/functions/api.mjs';
const origin='https://walletvera.netlify.app';
const cookie=()=>({host:'walletvera.netlify.app',origin,'sec-fetch-site':'same-origin'});
const event=(op,method='POST',data={})=>({httpMethod:method,queryStringParameters:{op},headers:cookie(),body:JSON.stringify(data)});
const originalFetch=globalThis.fetch;
afterEach(()=>{globalThis.fetch=originalFetch});
test('health does not claim database is connected',async()=>{const r=await handler(event('health','GET'));assert.equal(r.statusCode,200);assert.match(r.body,/integration tests/);});
test('blocks cross site signup, no remote auth call',async()=>{globalThis.fetch=()=>{throw Error('Called unexpected fetch')};const e=event('signup');e.headers.origin='https://attacker.example';const r=await handler(e);assert.equal(r.statusCode,403);});
test('rejects invalid email and weak password',async()=>{const r=await handler(event('signup','POST',{email:'oops',password:'123'}));assert.equal(r.statusCode,400);});
test('rejects mismatched passwords before remote signup',async()=>{const r=await handler(event('signup','POST',{name:'Vela Test',email:'test@example.com',password:'123456789012',confirmPassword:'mismatch'}));assert.equal(r.statusCode,400);});
test('signs up through Supabase Auth, returns server-side cookies',async()=>{
 globalThis.fetch=async(url,opts)=>{assert.ok(String(url).includes('/auth/v1/signup'));const p=JSON.parse(opts.body);assert.equal(p.data.full_name,'Test Name');return new Response(JSON.stringify({user:{id:'abc'},access_token:'fake.jwt',refresh_token:'fake.refresh',expires_in:3600}),{status:200})};
 const r=await handler(event('signup','POST',{name:'Test Name',email:'Test@example.com',password:'123456789012',confirmPassword:'123456789012'}));assert.equal(r.statusCode,201);assert.ok(r.multiValueHeaders['Set-Cookie'].every(c=>c.includes('HttpOnly')&&c.includes('SameSite=Strict')&&c.includes('Secure')));
});
test('cannot accept financial settlement requests without auth',async()=>{const r=await handler(event('deposit-approve','POST',{id:123}));assert.equal(r.statusCode,401);});
test('no credentials hardcoded in UI',async()=>{const {readFileSync}=await import('node:fs');const h=readFileSync('public/index.html','utf8');assert.ok(!h.includes('Vela#9Qm2!'));assert.ok(!h.includes('admin-setup-form'));assert.match(h,/Create Account/)});

test('anonymous visitor cannot inspect member balance or admin list',async()=>{
 const a=await handler(event('me','GET'));const b=await handler(event('admin','GET'));
 assert.equal(a.statusCode,401);assert.equal(b.statusCode,401);
});
test('ordinary member cannot call admin operations',async()=>{
 const uid='11111111-1111-4111-8111-111111111111';
 globalThis.fetch=async(url)=>{
  const path=String(url);
  if(path.endsWith('/auth/v1/user'))return new Response(JSON.stringify({id:uid,email:'member@example.com'}),{status:200});
  if(path.includes('wallet_profiles'))return new Response(JSON.stringify([{id:uid,email:'member@example.com',full_name:'Member',role:'user',active:true}]),{status:200});
  throw new Error('Unexpected call: '+path);
 };
 for(const op of ['admin','set-user']){
  const e=event(op,op==='admin'?'GET':'POST',{id:'22222222-2222-4222-8222-222222222222',active:false});
  e.headers.cookie='__Host-vela_access=local.mock.access';
  const r=await handler(e);assert.equal(r.statusCode,403,op);assert.match(r.body,/Administrator access required/);
 }
});
test('suspended member cannot access account',async()=>{
 const uid='11111111-1111-4111-8111-111111111111';
 globalThis.fetch=async(url)=>{
  const path=String(url);
  if(path.endsWith('/auth/v1/user'))return new Response(JSON.stringify({id:uid,email:'suspended@example.com'}),{status:200});
  if(path.includes('wallet_profiles'))return new Response(JSON.stringify([{id:uid,email:'suspended@example.com',role:'user',active:false}]),{status:200});
  throw new Error('Unexpected call');
 };
 const e=event('me','GET');e.headers.cookie='__Host-vela_access=local.mock.access';
 const r=await handler(e);assert.equal(r.statusCode,403);assert.match(r.body,/suspended/);
});
test('rejects public settlement requests even when authorization is not present',async()=>{
 const e=event('withdraw');const r=await handler(e);assert.equal(r.statusCode,401);
});
