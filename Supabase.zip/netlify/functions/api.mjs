// Vela Wallet / Supabase Auth gateway.
// Public publishable key ONLY. No service role, signing keys or blockchain fund transfers.
import {randomBytes} from 'node:crypto';

const BASE=(process.env.SUPABASE_URL||'https://bqydulyvwvywgpxrdeik.supabase.co').replace(/\/$/,'');
const KEY=process.env.SUPABASE_PUBLISHABLE_KEY||'sb_publishable_ikviNQHz6fR-jy1DVX4zJQ_LVxETBIr';
const AC='__Host-vela_access',RC='__Host-vela_refresh';
const COOKIE_OPTS='Path=/; HttpOnly; Secure; SameSite=Strict';
class Err extends Error {constructor(message,status=400){super(message);this.status=status;}}
function out(status,data,cookies=[]){const headers={'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};const r={statusCode:status,headers,body:JSON.stringify(data)};if(cookies.length)r.multiValueHeaders={'Set-Cookie':cookies};return r;}
function makeCookies(s){if(!s?.access_token||!s?.refresh_token)throw new Err('Authentication session unavailable.',503);let secs=Math.min(Math.max(Number(s.expires_in)||3600,60),3600);return [`${AC}=${encodeURIComponent(s.access_token)}; ${COOKIE_OPTS}; Max-Age=${secs}`,`${RC}=${encodeURIComponent(s.refresh_token)}; ${COOKIE_OPTS}; Max-Age=2592000`];}
function clearCookies(){return [`${AC}=; ${COOKIE_OPTS}; Max-Age=0`,`${RC}=; ${COOKIE_OPTS}; Max-Age=0`];}
function cookie(event,name){const all=event.headers?.cookie||event.headers?.Cookie||'';const match=all.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));if(!match)return '';try{return decodeURIComponent(match.slice(name.length+1))}catch{return ''}}
function originCheck(event){const origin=event.headers?.origin;const host=(event.headers?.host||'').toLowerCase();const expected=process.env.APP_ORIGIN?.replace(/\/$/,'')||`https://${host}`;
  if(!origin||origin!==expected)throw new Err('Request origin is not allowed. Verify APP_ORIGIN.',403);
  if(!host||new URL(expected).host.toLowerCase()!==host)throw new Err('Unexpected host.',403);
  const sf=event.headers?.['sec-fetch-site'];if(sf&&sf!=='same-origin'&&sf!=='none')throw new Err('Cross-site request blocked.',403);
}
function body(event){if((event.body||'').length>10000)throw new Err('Request too large.',413);try{const x=JSON.parse(event.body||'{}');if(!x||Array.isArray(x)||typeof x!=='object')throw 0;return x;}catch{throw new Err('Invalid request body.')}}
async function sb(path,{method='GET',payload,token}={}){const headers={apikey:KEY,accept:'application/json'};if(payload!==undefined)headers['content-type']='application/json';if(token)headers.authorization=`Bearer ${token}`;const ctl=new AbortController();const timeout=setTimeout(()=>ctl.abort(),11000);let res,raw;try{res=await fetch(BASE+path,{method,headers,body:payload===undefined?undefined:JSON.stringify(payload),signal:ctl.signal});raw=await res.text()}catch{throw new Err('Supabase connection failed. Try again later.',503)}finally{clearTimeout(timeout)}let data;try{data=raw?JSON.parse(raw):null}catch{data=null}
 if(!res.ok){const msg=data?.msg||data?.error_description||data?.message||data?.error||'Supabase request failed.';throw new Err(res.status===429?'Too many requests. Try again later.':String(msg).slice(0,180),res.status===429?429:res.status>=500?503:res.status)}return data;}
const rest=(table,params='',access)=>sb(`/rest/v1/${table}${params}`,{token:access});
async function session(event){let access=cookie(event,AC),refresh=cookie(event,RC),update=[];if(!access&&!refresh)throw new Err('Please sign in.',401);
 let u;try{if(access)u=await sb('/auth/v1/user',{token:access});}catch(e){if(e.status!==401&&e.status!==403)throw e;}
 if(!u?.id){if(!refresh)throw new Err('Session expired. Sign in again.',401);const s=await sb('/auth/v1/token?grant_type=refresh_token',{method:'POST',payload:{refresh_token:refresh}});access=s.access_token;update=makeCookies(s);u=s.user||await sb('/auth/v1/user',{token:access});}
 const ps=await rest('wallet_profiles',`?id=eq.${encodeURIComponent(u.id)}&select=id,email,full_name,role,active`,access);const profile=ps?.[0];if(!profile||!profile.active)throw new Err('Account unavailable or suspended.',403);
 return {access,u,profile,cookies:update};}
async function requireAdmin(s){if(s.profile.role!=='admin')throw new Err('Administrator access required.',403);}
function positiveAmount(input){const x=String(input||'').trim();if(!/^(?:0|[1-9]\d{0,12})(?:\.\d{1,18})?$/.test(x)||!/[1-9]/.test(x))throw new Err('Enter a positive amount with up to 18 decimals.');return x;}
function authInput(v){const email=String(v.email||'').trim().toLowerCase(),password=String(v.password||'');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)throw new Err('Enter a valid email address.');if(password.length<12||password.length>128)throw new Err('Password must contain 12–128 characters.');return {email,password};}
const fixed='0x0428211045A993b24cAe9fB8dDE2f9BFaee71c5a';
export async function handler(event){let cookies=[];try{const op=event.queryStringParameters?.op||'health',method=event.httpMethod||'GET';
 if(method==='GET'&&op==='health'){return out(200,{ok:true,service:'Vela Supabase gateway',auth:'server-side',note:'Database and login require integration tests.'})}
 if(method==='POST')originCheck(event);
 const v=method==='POST'?body(event):{};
 if(method==='POST'&&op==='signup'){
  const {email,password}=authInput(v);const full_name=String(v.name||'').trim().slice(0,100);if(full_name.length<2)throw new Err('Enter your full name.');if(password!==String(v.confirmPassword||''))throw new Err('Passwords do not match.');
  const result=await sb('/auth/v1/signup',{method:'POST',payload:{email,password,data:{full_name}}});
  if(!result?.access_token||!result?.refresh_token)return out(202,{ok:true,needsConfirmation:true,message:'Account request received, but email confirmation is enabled in Supabase. Disable Confirm Email as requested or verify the email.'});
  return out(201,{ok:true,message:'Account created.',user:{email,id:result.user?.id}},makeCookies(result));
 }
 if(method==='POST'&&op==='login'){
  const {email,password}=authInput(v);const s=await sb('/auth/v1/token?grant_type=password',{method:'POST',payload:{email,password}});
  return out(200,{ok:true,message:'Signed in.'},makeCookies(s));
 }
 if(method==='POST'&&op==='logout'){
  const access=cookie(event,AC);if(access){try{await sb('/auth/v1/logout',{method:'POST',token:access})}catch{ /* always clear local cookies */ }}
  return out(200,{ok:true},clearCookies());
 }
 if(!['GET','POST'].includes(method))throw new Err('Method not allowed.',405);
 const s=await session(event);cookies=s.cookies;const id=s.u.id;
 if(method==='GET'&&op==='me'){
   const [balance,claims]=await Promise.all([
     rest('wallet_balances',`?user_id=eq.${id}&select=asset,available,reserved`,s.access),
     rest('deposit_claims',`?user_id=eq.${id}&select=id,asset,amount,tx_hash,status,created_at&order=created_at.desc&limit=50`,s.access)]);
   const balances=Object.fromEntries((balance||[]).map(x=>[x.asset,{available:x.available,reserved:x.reserved}]));
   return out(200,{user:{id,name:s.profile.full_name||s.profile.email,email:s.profile.email,role:s.profile.role},balances,activity:(claims||[]).map(x=>({...x,kind:'deposit'})),address:fixed},cookies);
 }
 if(method==='GET'&&op==='admin'){
   await requireAdmin(s);
   const [profiles,balance,claims,audit]=await Promise.all([
     rest('wallet_profiles','?select=id,email,full_name,role,active,created_at&order=created_at.desc&limit=100',s.access),
     rest('wallet_balances','?select=user_id,asset,available,reserved&limit=300',s.access),
     rest('deposit_claims','?select=id,user_id,asset,amount,tx_hash,status,created_at&order=created_at.desc&limit=100',s.access),
     rest('wallet_audit','?select=id,action,subject_id,created_at&order=created_at.desc&limit=40',s.access)]);
   return out(200,{users:profiles.map(p=>({id:p.id,email:p.email,name:p.full_name||p.email,role:p.role,active:p.active,created_at:p.created_at,balances:balance.filter(b=>b.user_id===p.id)})),deposits:claims.map(c=>({...c,email:profiles.find(p=>p.id===c.user_id)?.email||'Unknown'})),withdrawals:[],audit,financialActionsEnabled:false,address:fixed},cookies);
 }
 if(method==='POST'&&op==='set-user'){
   await requireAdmin(s);if(typeof v.id!=='string'||!/^[a-f\d-]{36}$/i.test(v.id)||typeof v.active!=='boolean')throw new Err('Invalid member or status.');
   await sb('/rest/v1/rpc/wallet_admin_set_active',{method:'POST',token:s.access,payload:{p_user:v.id,p_active:v.active}});
   return out(200,{ok:true,message:v.active?'Member restored.':'Member suspended.'},cookies);
 }
 if(method==='POST'&&op==='claim'){
   const asset=String(v.asset||'');if(!['BNB','USDT'].includes(asset))throw new Err('Unsupported asset.');const amount=positiveAmount(v.amount),hash=String(v.hash||'').trim();if(!/^0x[0-9a-fA-F]{64}$/.test(hash))throw new Err('Invalid BSC transaction hash.');
   await sb('/rest/v1/deposit_claims',{method:'POST',token:s.access,payload:{user_id:id,asset,amount,tx_hash:hash}});
   return out(201,{ok:true,message:'Deposit claim submitted. It is NOT verified or credited. No balances change.'},cookies);
 }
 if(method==='POST'&&op==='password'){
   const current=String(v.currentPassword||''),next=String(v.newPassword||'');if(next.length<12||next.length>128)throw new Err('New password requires 12–128 characters.');
   await sb('/auth/v1/token?grant_type=password',{method:'POST',payload:{email:s.profile.email,password:current}});
   await sb('/auth/v1/user',{method:'PUT',token:s.access,payload:{password:next}});
   return out(200,{ok:true,message:'Password changed. Please sign in again.'},clearCookies());
 }
 if(method==='POST'&&['withdraw','deposit-approve','deposit-reject','withdraw-settle','withdraw-reject'].includes(op)){
   throw new Err('Financial settlement is not active. Requires independent security and BSC verification testing.',403);
 }
 throw new Err('Unknown endpoint.',404);
 }catch(e){return out(e.status||503,{ok:false,error:e.status?e.message:'Temporary server error. Check Supabase configuration and functions logs.'},cookies)}}
